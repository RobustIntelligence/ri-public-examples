import subprocess
from pathlib import Path
import os

PUBLIC_EXAMPLES_URL = (
    "https://raw.githubusercontent.com/RobustIntelligence/ri-public-examples/"
    "/jerry/offload_data_models/"
)

if __name__ == "__main__":
    script_path = os.path.join(PUBLIC_EXAMPLES_URL, "tabular/nyc_tlc/download_files.sh")
    # wget the script
    subprocess.call(["wget", script_path, "-O", "download_files.sh"])
    # run the script
    subprocess.call(["./download_files.sh", "test"])
    